if [ -e 1userlist.txt ]
then
echo "##########################################"
for i in `more userlist.txt `
do
echo "user - ""$i "
/usr/bin/sh /home/BUILDS/Pre-Requisites/changeUserRun.sh $i
echo "###########################################"
done
else
    echo "userlist.txt not found "
    exit 1
fi

echo "###########################################"
echo "       Finished creating test data         "
echo "###########################################"



