import os

print("Pre Run Running")
try:
  print(os.environ['pre_job_name'])
except:
  print("An exception occurred")

