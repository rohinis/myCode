#
# (c) Copyright 2017 Altair Engineering, Inc.  All rights reserved.
#
# This code is provided as is without any warranty, express or implied,
# or indemnification of any kind.
# All other terms and conditions are as specified in the Altair PBS EULA.
#

# TO DO:
# - add SMP executable support through the use of PBS App Svcs booleans
# - add support for multiple executable architecture and not only "p4linux964"
#   and make them choosen from interface and influencing submission (-> presubmit.py)
# - Fetch executables paths from site-config.xml

import time
import os
import sys
import subprocess
import base64
import fileinput

if sys.platform != 'win32':
    import resource

if sys.platform == 'win32':
    import win32api

### Print job environment ###
print("\n\nstart.py environment:")
for a in list(os.environ.keys()):
    var = a + '=' + os.environ[a]
    print(var)
print()

### Print and unlimit current limits for stack size and max locked memory
if sys.platform != 'win32':
    soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
    print('start.py: INFO: Stack size limit is (' + str(soft / 1024) + ',' + str(hard / 1024) + ').')
    soft, hard = resource.getrlimit(resource.RLIMIT_MEMLOCK)
    print('start.py: INFO: Max locked memory limit is (' + str(soft / 1024) + ',' + str(hard / 1024) + ').')

    print('start.py: INFO: Unlimit stack size')
    try:
        resource.setrlimit(resource.RLIMIT_STACK, (-1, hard))
        resource.setrlimit(resource.RLIMIT_STACK, (-1, soft))
    except ValueError as err:
        resource.error = err
        print('start.py: WARNING: Could not unlimit stack size.')

    soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
    print('start.py: INFO: Stack size limit is (' + str(soft / 1024) + ',' + str(hard / 1024) + ').')

    print('start.py: INFO: Unlimit max locked memory size')
    try:
        resource.setrlimit(resource.RLIMIT_MEMLOCK, (-1, hard))
        resource.setrlimit(resource.RLIMIT_MEMLOCK, (-1, soft))
    except ValueError as err:
        resource.error = err
        print('start.py: WARNING: Could not unlimit max locked memory.')

    soft, hard = resource.getrlimit(resource.RLIMIT_MEMLOCK)
    print('start.py: INFO: Max locked memory limit is (' + str(soft / 1024) + ',' + str(hard / 1024) + ').')

### Global constants and variables ###

### Set ALTAIR_LICENSE_PATH
if ("PAS_ALTAIR_LICENSE_PATH" in os.environ):
    os.environ['ALTAIR_LICENSE_PATH'] = os.environ['PAS_ALTAIR_LICENSE_PATH']
    print("start.py: INFO: ALTAIR_LICENSE_PATH is set to " + os.environ['ALTAIR_LICENSE_PATH'])
    sys.stdout.flush()
else:
    print("start.py: WARNING: No ALTAIR_LICENSE_PATH found in $aif_home/conf/site-config.xml")
    sys.stdout.flush()

# '''
# This is to replace the include file locations with the actual location during runtime
# PAS_INCLUDE_FIL_MAPPING will contain the information about include files in a key-value format separated by @@DELIM@@
# Key will contain the actual data that has to be replaced and value contains the data that has to be replaced with
# '''
if 'PAS_INCLUDE_FILE_MAPPING' in os.environ and os.environ['PAS_INCLUDE_FILE_MAPPING']:
    includeFilemap = os.environ['PAS_INCLUDE_FILE_MAPPING']
    includeFilemap = base64.b64decode(includeFilemap)
    includeFiles = includeFilemap.split('@@DELIM@@')
    for file in os.listdir('.'):
        if os.path.isfile(file):
            for includeFile in includeFiles:
                key = includeFile.split('=')[0]
                value = includeFile.split('=')[1]
                for line in fileinput.FileInput(file, inplace=True):
                    line = line.replace(key, value)
                    print(line, end=' ')

### Build application command line ###
PAS_EXECUTABLE = os.environ['PAS_EXECUTABLE']
if sys.platform == 'win32':
    PAS_EXECUTABLE = win32api.GetShortPathName(PAS_EXECUTABLE)

cmd = "\"" + PAS_EXECUTABLE + "\""
cmd += ' \"' + os.environ['PAS_PRIMARY_FILE'].split('/')[-1] + "\""
cmd += ' -nt ' + os.environ['NCPUS']
cmd += ' -v ' + os.environ['PAS_VERSION']
# if os.environ['PAS_PRECISION'] == 'Single Precision':
#  cmd += ' -sp'

#### run application
print("start.py: INFO: Running command " + cmd)
sys.stdout.flush()
os.system(cmd)

sys.stdout.flush()
