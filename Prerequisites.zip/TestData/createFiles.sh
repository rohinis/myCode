#!/bin/sh

echo "Bash version ${BASH_VERSION}..."
cd /stage/$1/
mkdir LotOfFiles
cd LotOfFiles
for ((n=1;n<=225;n++))
do
  touch $n.txt
  echo "File number $n" >> $n.txt
done
cd ..
chmod 777 -R LotOfFiles/*
chmod 777 *

ls -l /stage/$1 
