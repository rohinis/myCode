cd /stage/$1/

mkdir ShortCutFiles

cd  /stage/$1/ShortCutFiles/

cp  /stage/$1/JobsModule/InputDeck/*  /stage/$1/ShortCutFiles

ln -s /stage/$1/ShortCutFiles/Lag6elem_0000.rad /stage/$1/ShortCutFiles/SCLag6elem_0000.rad

ln -s /stage/$1/ShortCutFiles/Lag6elem_0001.rad /stage/$1/ShortCutFiles/SCLag6elem_0001.rad

ln -s /stage/$1/ShortCutFiles/bar.fem /stage/$1/ShortCutFiles/SCbar.fem

ln -s /stage/$1/ShortCutFiles/RunJob.sh /stage/$1/ShortCutFiles/SCRunJob.sh

chmod 777 -R /stage/$1/ShortCutFiles/

