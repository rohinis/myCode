#!/usr/bin/python
#
# (c) Copyright 2017 Altair Engineering, Inc.  All rights reserved.
#
# This code is provided as is without any warranty, express or implied,
# or indemnification of any kind.
# All other terms and conditions are as specified in the Altair PBS EULA.
#

import time
import os
import sys
import socket
import re
import subprocess
import base64
import fileinput

if sys.platform == 'win32':
    import win32api

hostname = socket.gethostname().split(".")[0]  # short hostname
#For windows file paths will be pbscp://
if sys.platform == 'win32':
    pas_submission_directory = re.sub(r'^pbscp://[^/]*/', '', os.environ['PAS_SUBMISSION_DIRECTORY'])
    pas_input_file = re.sub(r'^pbscp://[^/]*/', '', os.environ['PAS_PRIMARY_FILE'])
else:
    pas_submission_directory = re.sub(r'^pbscp://[^/]*/', '/', os.environ['PAS_SUBMISSION_DIRECTORY'])
    pas_input_file = re.sub(r'^pbscp://[^/]*/', '/', os.environ['PAS_PRIMARY_FILE'])
pas_job_name = os.environ["PAS_JOB_NAME"]
pas_application = os.environ["PAS_APPLICATION"]
pbs_job_dir = os.environ["PBS_JOBDIR"]

logfile_basename = pas_application + "-" + pas_job_name
stdout_logfile = logfile_basename + "-stdout.log"
stderr_logfile = logfile_basename + "-stderr.log"

if True:
    print("DEBUG: PBS Job dir is " + os.environ["PBS_JOBDIR"] + "\n")
    print("DEBUG: pas_submission_directory is " + pas_submission_directory + "\n")

# Look up the command to run
PAS_EXECUTABLE = os.environ['PAS_EXECUTABLE']
if sys.platform == 'win32':
    PAS_EXECUTABLE = win32api.GetShortPathName(PAS_EXECUTABLE)

cmd = PAS_EXECUTABLE

# '''
# This is to replace the include file locations with the actual location during runtime
# PAS_INCLUDE_FIL_MAPPING will contain the information about include files in a key-value format separated by @@DELIM@@
# Key will contain the actual data that has to be replaced and value contains the data that has to be replaced with
# '''
if 'PAS_INCLUDE_FILE_MAPPING' in os.environ and os.environ['PAS_INCLUDE_FILE_MAPPING']:
    includeFilemap = os.environ['PAS_INCLUDE_FILE_MAPPING']
    includeFilemap = base64.b64decode(includeFilemap.encode()).decode()
    includeFiles = includeFilemap.split('@@DELIM@@')
    for file in os.listdir('.'):
        if os.path.isfile(file):
            for includeFile in includeFiles:
                key = includeFile.split('=')[0]
                value = includeFile.split('=')[1]
                for line in fileinput.FileInput(file, inplace=True):
                    line = line.replace(key, value)
                    print(line, end=' ')

os.environ['TEMP'] = os.environ['TMPDIR']

sys.stdout.flush()
sys.stderr.flush()

# run application
print(cmd)

print(pas_input_file)
job_script = os.path.basename(os.environ['PAS_PRIMARY_FILE'])
job_script = job_script.replace('%20', ' ')
print(job_script)

solver = subprocess.Popen(
    "\"" + cmd + "\" \"" + job_script + "\" > \"" + stdout_logfile + "\" 2> \"" + stderr_logfile + "\"", shell=True)
solver.wait()
