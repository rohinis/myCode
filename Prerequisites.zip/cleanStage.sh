#!/bin/sh
if [ -e userlist.txt ]
then
echo "###########################################"
for i in `more userlist.txt `
do
echo "Cleaning - /stage/""$i "
cd /stage/$i
rm -rf *
echo "###########################################"
done

echo "Deletig all jobs from pbs - including job history"
echo "###########################################"

qstat
qdel -x `qselect -x`
qdel -W force  `qselect`
qstat
else
    echo "userlist.txt not found "
    exit 1
fi
