#!/usr/bin/python

import time
import os
import sys

script=sys.argv[0]
print("Executing script: " + script)
sys.stdout.flush()
