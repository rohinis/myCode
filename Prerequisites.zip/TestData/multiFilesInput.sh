cd /stage/$1/


cp CURRENT_PATH/MultiFiles.tar .

tar -xvf MultiFiles.tar

cd MultiFiles

unzip  MultipleFilesIconsJS.zip
unzip  MultipleFilesJS.zip
unzip  MultipleFolderFilesIconsJS.zip
unzip  MultipleFolderFilesJS.zip
unzip  MultipleFolderIconsJS.zip
unzip  MultipleFolderJS.zip

