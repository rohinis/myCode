import sys
import os
import base64
################################################################################
#'''
# masterFilePath: Path for master file that has to be read
# includeKeyName: The key/ include name that has to be searched in the master
# isIncludeInNextLine: This decides on whether the include file path is in next line or not
#
#
# Used Vars:
#	includeFileMap: This list is a key-value pair that will be set as an env which will be used
#					to replace during execution in the master file
#'''

def identifyIncludesInFile(filePath, includeKeyName, isIncludeInNextLine):
	includeFileMap = ""
	masterFileDirPath = filePath[:filePath.rindex('/')]
	# Open the file
	if filePath and os.path.exists(filePath) and os.path.isfile(filePath):
		masterFP = open(filePath)
		includeFilePaths = []
		#Variable to check whether file exists or not
		includeFiles = []
		# Loop through all lines to identify the includes
		for line in masterFP:
			line = line.strip()
			if not line:
				continue
			# If line starts with the incldue key then read the include file path 
			if line.startswith(includeKeyName):
				if isIncludeInNextLine:
					includeFileLine = next(masterFP)
					includeFileLine = includeFileLine.strip()
					includeFilePath = includeFileLine.replace("'","")
				else:
					includeFilePath = line[len(includeKeyName):].replace("'","")
				includeFileName = os.path.basename(includeFilePath)
				#Allow only if file doesn't exists
				if includeFileName not in includeFiles:
					includeFiles.append(includeFileName)
					# If the path is absolute then add the file path directly otherwise append the masterFileDirPath to the actual includeFilePath
					if os.path.isabs(includeFilePath):
						includeFileMap = includeFileMap + "@@DELIM@@"+ includeFilePath + "=" + os.path.basename(includeFilePath)
						includeFilePath = includeFilePath.replace("\\", "/")
						includeFilePaths.append(includeFilePath)
					else:
						if("/" in includeFilePath or "\\" in includeFilePath):
							includeFileMap = includeFileMap + "@@DELIM@@"+ includeFilePath + "=" + os.path.basename(includeFilePath)
						includeFilePath = masterFileDirPath+ "/" + includeFilePath
						includeFilePath = includeFilePath.replace("\\", "/")
						includeFilePaths.append(includeFilePath)
		if includeFileMap:
			if(includeFileMap.startswith("@@DELIM@@")):
				includeFileMap = includeFileMap[len("@@DELIM@@"):]
		masterFP.close()
		return includeFilePaths,includeFileMap
	else:
		print("File " + filePath + " doesn't exist", file=sys.stderr)
		return None, None

globIncludeFileMap = ""
globincludeFilePaths = []
glob_temp_file_paths = []

def parseMasterFileForIncludePaths(masterFilePath, includeKeyName, isIncludeInNextLine, recursive=True):
	global globincludeFilePaths
	global globIncludeFileMap
	global glob_temp_file_paths
	
	masterFilePath = masterFilePath.replace("\\", "/")
	if masterFilePath.startswith("pbscp"):
		masterFilePath = masterFilePath.replace("pbscp://","")
		masterFilePath = masterFilePath[masterFilePath.index('/') + 1:]
		import re
		if not re.match(r'^[a-zA-Z]:', masterFilePath):
			masterFilePath = "/" + masterFilePath
	tempincludeFilePaths,tempIncludeFileMap = identifyIncludesInFile(masterFilePath, includeKeyName, isIncludeInNextLine)
	if tempIncludeFileMap:
		if globIncludeFileMap:
			globIncludeFileMap = globIncludeFileMap + "@@DELIM@@" + tempIncludeFileMap
		else:
			globIncludeFileMap = tempIncludeFileMap
	if tempincludeFilePaths:
		globincludeFilePaths = globincludeFilePaths + tempincludeFilePaths
		glob_temp_file_paths = glob_temp_file_paths + tempincludeFilePaths

	if glob_temp_file_paths and recursive:
		filePath = glob_temp_file_paths[0]
		glob_temp_file_paths.remove(filePath)
		parseMasterFileForIncludePaths(filePath, includeKeyName, isIncludeInNextLine, recursive)
	return globincludeFilePaths,globIncludeFileMap

################################################################################
